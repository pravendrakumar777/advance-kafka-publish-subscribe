package com.rnsoftech;

import com.rnsoftech.domain.User;
import com.rnsoftech.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedKafkaPubSubApplicationTests {

	@Autowired
	private UserService userService;

	@Test
	void testLoggingAspect() {
		User user = new User();
		userService.create(user);
	}

	@Test
	void contextLoads() {
	}
}

package com.rnsoftech.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
    private final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    // Pointcut for all service methods
    @Pointcut("execution(* com.rnsoftech.service..*(..))")
    public void serviceMethods() {}

    // Pointcut for all resource methods
    @Pointcut("execution(* com.rnsoftech.resource..*(..))")
    public void resourceMethods() {}

    // Log before method execution
    @Before("serviceMethods() || resourceMethods()")
    public void logBefore(JoinPoint joinPoint) {
        log.info("Entering method: {} with arguments: {}",
                joinPoint.getSignature().toShortString(),
                joinPoint.getArgs());
    }

    // Log after method execution
    @After("serviceMethods() || resourceMethods()")
    public void logAfter(JoinPoint joinPoint) {
        log.info("Exiting method: {}", joinPoint.getSignature().toShortString());
    }

    // Log return values
    @AfterReturning(pointcut = "serviceMethods() || resourceMethods()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        log.info("Method {} returned: {}", joinPoint.getSignature().toShortString(), result);
    }

    // Log exception
    @AfterThrowing(pointcut = "serviceMethods() || resourceMethods()", throwing = "ex")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable ex) {
        log.error("Method {} threw exception: {}", joinPoint.getSignature().toShortString(), ex.getMessage(), ex);
    }

    // Measure execution time
    @Around("serviceMethods() || resourceMethods()")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Object proceed;
        try {
            proceed = joinPoint.proceed();
        } catch (Throwable throwable) {
            log.error("Exception in method: {}", joinPoint.getSignature(), throwable);
            throw throwable;
        }
        long duration = System.currentTimeMillis() - start;
        log.info("Execution time of {} :: {} ms", joinPoint.getSignature().toShortString(), duration);
        return proceed;
    }
}

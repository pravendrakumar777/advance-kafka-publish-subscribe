package com.rnsoftech.service.impl.listeners;

import com.rnsoftech.config.ConfigChannel;
import com.rnsoftech.domain.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

@Component
public class UserListener {
    private static final Logger log = LoggerFactory.getLogger(UserListener.class);

    @ServiceActivator(inputChannel = ConfigChannel.USER_DETAILS_INPUT)
    public void userEventHandler(User user) {
        log.info("User Event Handled/Subscribed Successfully: {}", user);
    }

    @ServiceActivator(inputChannel = ConfigChannel.USER_DETAILS_INPUT)
    public void userEventHandler2(User user) {
        log.info("User Event Handled2/Subscribed Successfully: {}", user);
    }

    @ServiceActivator(inputChannel = ConfigChannel.USER_DETAILS_INPUT)
    public void userEventHandler3(User user) {
        log.info("User Event Handled3/Subscribed Successfully: {}", user);
    }
}

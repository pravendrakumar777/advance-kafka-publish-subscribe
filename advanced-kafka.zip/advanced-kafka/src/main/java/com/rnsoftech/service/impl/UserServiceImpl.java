package com.rnsoftech.service.impl;

import com.rnsoftech.config.ConfigChannel;
import com.rnsoftech.domain.User;
import com.rnsoftech.repository.UserRepository;
import com.rnsoftech.service.UserService;
import com.rnsoftech.service.impl.publisher.UserPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    private final UserRepository userRepository;
    private final ConfigChannel bindingChannel;
    private final UserPublisher userPublisher;

    public UserServiceImpl(UserRepository userRepository, ConfigChannel bindingChannel, UserPublisher userPublisher) {
        this.userRepository = userRepository;
        this.bindingChannel = bindingChannel;
        this.userPublisher = userPublisher;
    }

    @Override
    public User create(User user) {
        log.info("Service Request to create: {}", user);
        User result = userRepository.save(user);
        MessageChannel userOutputMessageChannel = bindingChannel.userDetailsOutput();
        userOutputMessageChannel.send(MessageBuilder.withPayload(result).build());
        return result;
    }

    @Override
    public List<User> fetchAllUsers() {
        log.info("Service Request to fetchAllUsers: {}");
        List<User> userList = userRepository.findAll();
        return userList;
    }
}

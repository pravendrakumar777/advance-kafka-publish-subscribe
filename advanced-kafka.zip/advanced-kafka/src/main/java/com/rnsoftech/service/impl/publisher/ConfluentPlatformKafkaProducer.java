package com.rnsoftech.service.impl.publisher;

import com.rnsoftech.domain.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ConfluentPlatformKafkaProducer {
    private static final Logger log = LoggerFactory.getLogger(ConfluentPlatformKafkaProducer.class);
    private final KafkaTemplate<String, User> kafkaTemplate;
    private static final String CONFLUENT_PLATFORM_USER_PRODUCER = "confluent-platform-producer";

    public ConfluentPlatformKafkaProducer(KafkaTemplate<String, User> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessageConfluentPlatform(String key, User user) {
        kafkaTemplate.send(CONFLUENT_PLATFORM_USER_PRODUCER, key, user);
        log.info("Confluent Platform Message Event Published Successfully!! sendMessageConfluentPlatform: {}", user);
    }
}

package com.rnsoftech.service.impl.publisher;

import com.rnsoftech.config.ConfigChannel;
import com.rnsoftech.domain.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class UserPublisher {
    private static final Logger log = LoggerFactory.getLogger(UserPublisher.class);
    private final ConfigChannel configChannel;
    public UserPublisher(ConfigChannel configChannel) {
        this.configChannel = configChannel;
    }
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void publishUserEvent(User user) {
        log.info("Published User Event: {}", user);
        MessageChannel userOutput = configChannel.userDetailsOutput();
        userOutput.send(MessageBuilder.withPayload(userOutput).build());
    }
}

package com.rnsoftech.service.impl.listeners;

import com.rnsoftech.domain.User;
import com.rnsoftech.service.impl.publisher.ConfluentPlatformKafkaProducer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ConfluentPlatformKafkaConsumer {
    private static final Logger log = LoggerFactory.getLogger(ConfluentPlatformKafkaConsumer.class);

    public void consumeMessageConfluentPlatform(ConsumerRecord<String, User> record) {
        User value = record.value();
        log.info("Confluent Platform Message Consumed Successfully!! consumeMessageConfluentPlatform key: {}, value: {}", record.key(), value);
    }
}

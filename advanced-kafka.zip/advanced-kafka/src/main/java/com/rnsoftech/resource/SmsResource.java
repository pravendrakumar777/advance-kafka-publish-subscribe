package com.rnsoftech.resource;

import com.rnsoftech.service.impl.SmsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class SmsResource {
    private final SmsService smsService;
    public SmsResource(SmsService smsService) {
        this.smsService = smsService;
    }
    @PostMapping("/send")
    public String sendSms(@RequestParam String message) {
        String toPhoneNumber = "+918095216322";
        String sid = smsService.sendMessage(toPhoneNumber, message);
        return "Message sent successfully! SID: " + sid;
    }
}

package com.rnsoftech.resource;

import com.rnsoftech.domain.User;
import com.rnsoftech.service.UserService;
import com.rnsoftech.service.impl.publisher.ConfluentPlatformKafkaProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserResource {
    private static final Logger log = LoggerFactory.getLogger(UserResource.class);
    private final UserService userService;
    private final ConfluentPlatformKafkaProducer confluentPlatformKafkaProducer;


    public UserResource(UserService userService, ConfluentPlatformKafkaProducer confluentPlatformKafkaProducer) {
        this.userService = userService;
        this.confluentPlatformKafkaProducer = confluentPlatformKafkaProducer;
    }

    @PostMapping("/users/publish")
    public ResponseEntity<?> publishUser(@RequestBody User user) {
        log.info("REST Request to publishUser: {}", user);
        User result = userService.create(user);
        return ResponseEntity.ok().body(result);
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> fetchAll() {
        log.info("REST Request to publishUser: {}");
        List<User> result = userService.fetchAllUsers();
        return ResponseEntity.ok().body(result);
    }

    @PostMapping("/publish")
    public ResponseEntity<String> publish(@RequestBody User user) {
        confluentPlatformKafkaProducer.sendMessageConfluentPlatform(String.valueOf(user.getId()), user);
        return ResponseEntity.ok("Message published to Kafka");
    }
}

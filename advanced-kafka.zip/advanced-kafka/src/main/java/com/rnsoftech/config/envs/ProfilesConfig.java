package com.rnsoftech.config.envs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
@Configuration
public class ProfilesConfig {

    @Bean
    @Profile("dev")
    public MyService devService() {
        System.out.println("Development Environment");
        return new MyService("Service is active in DEV Environment");
    }

    @Bean
    @Profile("prod")
    public MyService prodService() {
        System.out.println("Production Environment");
        return new MyService("Service is active in PROD Environment");
    }

    @Bean
    @Profile("test")
    public MyService testService() {
        System.out.println("Testing Environment");
        return new MyService("Service is active in TEST Environment");
    }

    @Bean
    @Profile("uat")
    public MyService uatService() {
        System.out.println("UAT Environment");
        return new MyService("Service is active in UAT Environment");
    }
    @Bean
    @Profile("stage")
    public MyService stageService() {
        System.out.println("Stage Environment");
        return new MyService("Service is active in STAGE Environment");
    }
}

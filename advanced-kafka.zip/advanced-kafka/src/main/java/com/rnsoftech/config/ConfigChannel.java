package com.rnsoftech.config;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.SubscribableChannel;

public interface ConfigChannel {
    String USER_DETAILS_OUTPUT = "user-details-output";
    @Output(USER_DETAILS_OUTPUT)
    SubscribableChannel userDetailsOutput();

    String USER_DETAILS_INPUT = "user-details-input";
    @Input(USER_DETAILS_INPUT)
    SubscribableChannel userDetailsInput();
}
